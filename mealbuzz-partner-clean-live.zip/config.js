// Optional Supabase setup. Site works in local demo mode until these are filled.
window.MEALBUZZ_CONFIG = {
  SUPABASE_URL: "",
  SUPABASE_ANON_KEY: ""
};

# Meal Buzz Partner
Clean static partner page for GitHub Pages.

Live URL after Pages is enabled:
https://avdhane1969-dap.github.io/mealbuzz-partner/

Upload all files to the root of the `main` branch. Then enable GitHub Pages from Settings → Pages → Deploy from branch → main → /root.
